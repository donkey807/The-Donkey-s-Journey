/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2026-05-18     刘庆凯       the first version
 */
#include "sensor.h"

//亮度传感器
rt_uint8_t LightSensor_Get(void)
{
    return rt_pin_read(LIGHT_PIN);
}

//温湿度传感器

dht11_data_t dht11_data = {0};
void DHT11_GPIO_Init_OUT(void)
{
    rt_pin_mode(DHT11_PIN,PIN_MODE_OUTPUT);

}
void DHT11_GPIO_Init_IN(void)
{
    // 用内部上拉输入：无外部4.7kΩ时总线不会浮空，DHT11的响应低电平可被正确识别
    rt_pin_mode(DHT11_PIN, PIN_MODE_INPUT_PULLUP);
}

void DHT11_Start(void)
{
    DHT11_GPIO_Init_OUT();
    dht11_high();
    rt_thread_mdelay(1);

    dht11_low();
    rt_thread_mdelay(20);   // 必须 ≥18ms

    dht11_high();
    rt_hw_us_delay(30);
    DHT11_GPIO_Init_IN();
}
unsigned char DHT11_REC_Byte(void)
{
    unsigned char i=0, data=0;

    for(i=0;i<8;i++)
    {
        while(Read_Data() == 0);
        rt_hw_us_delay(30);

        data <<= 1;

        if(Read_Data() == 1)
            data |= 1;

        while(Read_Data() == 1);
    }
    return data;
}



// 这是你最终能用的 100% 正确版本
void DHT11_REC_Data(void)
{
    unsigned char R_H,R_L, T_H,T_L,CHECK;
    rt_uint32_t timeout;

    DHT11_Start();

    // 等待响应
    timeout = 100;
    while(Read_Data() == 1)
    {
        rt_hw_us_delay(1);
        if(--timeout == 0)
        {
            //rt_kprintf("[DHT11] no respondding！\n");
            goto end;
        }
    }

    // 等待低电平
    timeout = 100;
    while(Read_Data() == 0)
    {
        rt_hw_us_delay(1);
        if(--timeout == 0) goto end;
    }

    // 等待高电平
    timeout = 100;
    while(Read_Data() == 1)
    {
        rt_hw_us_delay(1);
        if(--timeout == 0) goto end;
    }

    // ====================== 必须读 5 个字节 ======================
    R_H   = DHT11_REC_Byte();  // 湿度整数
    T_H   = DHT11_REC_Byte();  // 温度整数
    CHECK = DHT11_REC_Byte();  // 校验

    // 校验
    if( (R_H + T_H) == CHECK )
    {
        dht11_data.humi = R_H;
        dht11_data.temp = T_H;
    }
    else
    {
        rt_kprintf("[DHT11] check error\n");
    }

end:
    return;
}
