/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2026-05-20     刘庆凯       the first version
 */
#include "terminal.h"
#include <rtthread.h>
#include "lcd.h"
#include "stm32f1xx_hal.h"
#include "main.h"
void set_pc4_high(void)
{
    rt_pin_mode(GET_PIN(C,4), PIN_MODE_OUTPUT);
    rt_pin_write(GET_PIN(C,4), PIN_HIGH);
    rt_kprintf("PC4 → HIGH\n");
}

// 命令2：PB13 输出低
void set_pc4_low(void)
{
    rt_pin_mode(GET_PIN(C,4), PIN_MODE_OUTPUT);
    rt_pin_write(GET_PIN(C,4), PIN_LOW);
    rt_kprintf("PC4 → LOW\n");
}

// 导出命令 → 终端就能用
MSH_CMD_EXPORT(set_pc4_high,  set PC4 high);//命令set_pc4_high 解释set PC4 high
MSH_CMD_EXPORT(set_pc4_low,   set PC4 low);
