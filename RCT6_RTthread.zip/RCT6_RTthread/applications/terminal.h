/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2026-05-20     刘庆凯       the first version
 */
#ifndef APPLICATIONS_TERMINAL_H_
#define APPLICATIONS_TERMINAL_H_
#include <rtdevice.h>

void set_pb13_high(void);
void set_pb13_low(void);

#endif /* APPLICATIONS_TERMINAL_H_ */
