/*
 * Copyright (c) 2006-2026, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2026-04-29     刘庆凯
 */
//main()
//├─ 初始化所有设备（LCD、DHT11、ADC、RTC）
//├─ 创建：消息队列 1 个
//├─ 创建：信号量 1 个
//└─ 创建 4 个线程
//
//1. 线程1：时间采集线程（RTC）
//   → 读取时间 → 发送到消息队列
//2. 线程2：温湿度采集线程（DHT11）和光照采集（ADC）
//   → 读取数据 → 发送到消息队列
//3. 线程3：LCD 显示线程
//   → 从消息队列接收数据 → 刷新屏幕
/*终端
 * PA9 RXD
 * PA10 TXD
 *
 * lcd引脚定义（硬件SPI）
 * SPI1: PA5(SCK), PA7(MOSI) — 硬件驱动
 * RST  -> PB6
 * DC   -> PB7
 * CS   -> PB8（软件控制，SPI1 NSS）
 * BLK  -> PB9（背光）
 *
 *温湿度传感器 PB13
 *亮度传感器 PB8
 * */

#include <rtthread.h>
#include "lcd.h"
#include "sensor.h"
#include <time.h>
#include <rtdevice.h>
#include <stdio.h>
struct rt_data_queue sensor_queue;//数据队列用于存传感器数据

typedef struct {
    uint8_t temp;   // 1字节
    uint8_t humi;   // 1字节
    uint8_t light;  // 1字节
} sensor_data_t;   // 一共 3 字节

/* set_date/set_time 实现 - 供 libc 调用 */
rt_err_t set_date_use(rt_uint32_t year, rt_uint32_t month, rt_uint32_t day)
{
    rt_device_t rtc_dev;
    time_t now;
    struct tm p_tm;

    /* 获取当前时间 */
    now = time(RT_NULL);
    localtime_r(&now, &p_tm);

    /* 设置日期 */
    p_tm.tm_year = year - 1900;
    p_tm.tm_mon = month - 1;
    p_tm.tm_mday = day;
    now = mktime(&p_tm);

    /* 查找 RTC 设备并设置时间 */
    rtc_dev = rt_device_find("rtc");
    if (rtc_dev == RT_NULL)
        return -RT_ERROR;
    return rt_device_control(rtc_dev, RT_DEVICE_CTRL_RTC_SET_TIME, &now);
}
rt_err_t set_time_use(rt_uint32_t hour, rt_uint32_t minute, rt_uint32_t second)
{
    rt_device_t rtc_dev;
    time_t now;
    struct tm p_tm;

    /* 获取当前时间 */
    now = time(RT_NULL);
    localtime_r(&now, &p_tm);

    /* 设置时间 */
    p_tm.tm_hour = hour;
    p_tm.tm_min = minute;
    p_tm.tm_sec = second;
    now = mktime(&p_tm);

    /* 查找 RTC 设备并设置时间 */
    rtc_dev = rt_device_find("rtc");
    if (rtc_dev == RT_NULL)
        return -RT_ERROR;
    return rt_device_control(rtc_dev, RT_DEVICE_CTRL_RTC_SET_TIME, &now);
}
static void lcd_thread_entry(void *param)
{

    const void *ptr = RT_NULL;
    rt_size_t   sz  = 0;
    char tmp_buf[8];



    rt_kprintf("[LCD] thread start\n");

    /* 初始化 LCD（内部已初始化GPIO+背光） */
    LCD_Init();
    rt_kprintf("[LCD] init done\n");

    /* 清屏 */
    LCD_Fill(0, 0, LCD_W - 1, LCD_H - 1, BLACK);
    rt_kprintf("[LCD] fill black done\n");

    /* 背景 */
    LCD_Fill(0, 0, LCD_W - 1, LCD_H - 1, Chocolate);

    rt_kprintf("[LCD] bars done\n");



    /* 显示字符串 */
    LCD_ShowString(0, 0,  "Hello!",         GOLD, Chocolate);
    LCD_ShowString(0, 50,  "RT-Thread OK",   GOLD, Chocolate);

    rt_kprintf("[LCD] display ok\n");



    while (1)
    {
        rt_data_queue_pop(&sensor_queue, &ptr, &sz, 10);//&ptr=**ptr

        if (sz == sizeof(sensor_data_t))
        {
            sensor_data_t *p = (sensor_data_t *)ptr;

            time_t now = time(NULL);
            struct tm *t = localtime(&now);

            char buf[10];

            /* 先用背景色覆盖之前的数字区域 */
            LCD_Fill(0, 214, 120, 214 + 24, Chocolate);

            /* 填充新时间字符串 */
            sprintf(buf, "%02d:%02d:%02d", t->tm_hour, t->tm_min, t->tm_sec);

            /* 显示时间 */
            LCD_ShowString(0, 100, buf, GOLD, Chocolate);
            sprintf(tmp_buf, "temperature: %u", p->temp);
            LCD_ShowString(0, 140,tmp_buf, GOLD, Chocolate);

            sprintf(tmp_buf, "humidity: %u", p->humi);
            LCD_ShowString(0, 180,tmp_buf, GOLD, Chocolate);
            sprintf(tmp_buf, "light: %u", p->light);
            LCD_ShowString(0, 220,tmp_buf, GOLD, Chocolate);

        }
        rt_thread_mdelay(100);
    }
}

static void led_thread_entry(void *param)
{
    rt_base_t pin = (rt_base_t)param;

    rt_pin_mode(pin, PIN_MODE_OUTPUT);


    while(1)
    {
        rt_pin_write(pin, PIN_HIGH);
        rt_thread_mdelay(1000);
        rt_pin_write(pin, PIN_LOW);
        rt_thread_mdelay(1000);
    };

}



static void sensor_thread_entry(void *param)
{
    rt_err_t ret = RT_EOK;
    rt_uint8_t val1;
    rt_uint8_t val2;

    sensor_data_t data_push = {0};//传感器线程里获取数据

    while(1)
    {

        //温湿度传感器
        DHT11_REC_Data(); //接收温度和湿度的数据
        //rt_kprintf("temperature = %d\n", dht11_data.temp);
        //rt_kprintf("humidity = %d\n", dht11_data.humi);
        data_push.temp = dht11_data.temp;
        data_push.humi = dht11_data.humi;

        //亮度传感器
        val1 = LightSensor_Get();
        rt_thread_mdelay(20);  // 延时20ms
        val2 = LightSensor_Get();

        // 两次一样才认为有效
        if(val1 == val2)
        {
                //rt_kprintf("light = %d\n", val1);
                data_push.light = val1;
        }
        ret = rt_data_queue_push(&sensor_queue, &data_push, sizeof(data_push),10);

        if (ret != RT_EOK)
        {
            rt_kprintf("queue push failed: %d\n", ret);
        }
        rt_thread_mdelay(1000);

    }
}

int main(void)
{
    rt_err_t ret = RT_EOK;

    ret = rt_data_queue_init(&sensor_queue, 10, 2, RT_NULL);
    if (ret != RT_EOK)
        {
            rt_kprintf("data_queue_init failed\n");
            return ret;
        }
    /* 设置日期 */
    ret = set_date_use(2026, 5, 1);
    if (ret != RT_EOK)
    {
        rt_kprintf("set RTC date failed\n");
        return ret;
    }

    /* 设置时间 */
    ret = set_time_use(18, 41, 0);
    if (ret != RT_EOK)
    {

        rt_kprintf("set RTC time failed\n");
        return ret;
    }


        /* 延时3秒 */
    rt_thread_mdelay(3000);


    rt_kprintf("[MAIN] start\n");


    rt_thread_t tid1 = rt_thread_create(
        "lcd",
        lcd_thread_entry,
        RT_NULL,
        2048,
        15,
        10
    );

    rt_thread_t tid2 = rt_thread_create(
            "led",
            led_thread_entry,
            (void*)GET_PIN(A,4),
            512,
            15,
            10);
    rt_thread_t tid3 = rt_thread_create(
            "sensor",
            sensor_thread_entry,
            RT_NULL,
            512,
            15,
            10);
    if (tid1 != RT_NULL && tid2 != RT_NULL && tid3 != RT_NULL)
    {
        rt_thread_startup(tid1);
        rt_thread_startup(tid2);
        rt_thread_startup(tid3);
    }
    else
        rt_kprintf("[MAIN] thread create failed\n");


    return RT_EOK;
}

