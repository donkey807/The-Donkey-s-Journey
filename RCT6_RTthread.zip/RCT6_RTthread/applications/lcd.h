/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2026-05-01     刘庆凯       改用硬件SPI
 */
#ifndef APPLICATIONS_LCD_H_
#define APPLICATIONS_LCD_H_

#include <rtthread.h>
#include <rtdevice.h>
#include "../drivers/board.h"

/* 屏幕分辨率（ST7789V 240x320 竖屏） */
#define LCD_W  240
#define LCD_H  320

/*
 * 引脚定义（硬件SPI）
 * SPI1: PA5(SCK), PA7(MOSI) — 硬件驱动
 * RST  -> PB6
 * DC   -> PB7
 * CS   -> PB8（软件控制，SPI1 NSS）
 * BLK  -> PB9（背光）
 */
#define LCD_RST_CLR()    rt_pin_write(GET_PIN(B, 6), PIN_LOW)
#define LCD_RST_SET()    rt_pin_write(GET_PIN(B, 6), PIN_HIGH)
#define LCD_DC_CLR()     rt_pin_write(GET_PIN(B, 7), PIN_LOW)
#define LCD_DC_SET()     rt_pin_write(GET_PIN(B, 7), PIN_HIGH)
#define LCD_CS_CLR()     rt_pin_write(GET_PIN(B, 8), PIN_LOW)
#define LCD_CS_SET()     rt_pin_write(GET_PIN(B, 8), PIN_HIGH)
#define LCD_BLK_SET()    rt_pin_write(GET_PIN(B, 9), PIN_HIGH)
#define LCD_BLK_CLR()    rt_pin_write(GET_PIN(B, 9), PIN_LOW)

/* RGB565 颜色 */
#define WHITE    0xFFFF
#define BLACK    0x0000
#define RED      0xF800
#define GREEN    0x07E0
#define BLUE     0x001F
#define YELLOW   0xFFE0
#define CYAN     0x07FF
#define MAGENTA  0xF81F
#define SKYBLUE   0x867D
#define GOLD      0xFEA0    // 金
#define SILVER    0xC618    // 银
#define Chocolate 0x1A10    //深棕色
/* SPI设备名称（需在CubeMX/SPI配置中开启SPI1） */
#define LCD_SPI_DEVICE  "spi10"

/* 接口函数 */
void LCD_Init(void);
void LCD_Fill(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t color);
void LCD_DrawPoint(uint16_t x, uint16_t y, uint16_t color);
void LCD_ShowChar(uint16_t x, uint16_t y, char ch, uint16_t fc, uint16_t bc);
void LCD_ShowString(uint16_t x, uint16_t y, const char *str, uint16_t fc, uint16_t bc);

#endif /* APPLICATIONS_LCD_H_ */
