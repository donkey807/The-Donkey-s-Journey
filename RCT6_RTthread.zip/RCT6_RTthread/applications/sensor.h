/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2026-05-18     刘庆凯       the first version
 * 多种传感器的传输
 */
#ifndef APPLICATIONS_SENSOR_H_
#define APPLICATIONS_SENSOR_H_

#include <rtthread.h>
#include <rtdevice.h>
#include "../drivers/board.h"
//亮度传感器
#define LIGHT_PIN    GET_PIN(C, 8)
rt_uint8_t LightSensor_Get(void);

//温湿度传感器
typedef struct {
    uint8_t humi;  // 湿度
    uint8_t temp;  // 温度
} dht11_data_t;   // 总大小：2 字节
extern dht11_data_t dht11_data;

#define DHT11_PIN   GET_PIN(B,12)
#define dht11_high() rt_pin_write(DHT11_PIN,1)
#define dht11_low() rt_pin_write(DHT11_PIN,0)
#define Read_Data() rt_pin_read(DHT11_PIN)
void DHT11_GPIO_Init_OUT(void);
void DHT11_GPIO_Init_IN(void);
void DHT11_Start(void);
unsigned char DHT11_REC_Byte(void);
void DHT11_REC_Data(void);


#endif /* APPLICATIONS_SENSOR_H_ */
