rt-thread/libcpu/arm/common/div0.o: ../rt-thread/libcpu/arm/common/div0.c \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rtconfig_preinc.h

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rtconfig_preinc.h:
