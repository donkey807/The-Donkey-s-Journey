rt-thread/components/drivers/spi/spi_core.o: \
 ../rt-thread/components/drivers/spi/spi_core.c \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rtconfig_preinc.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\components\drivers\include/drivers/spi.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/rtthread.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread/rtconfig.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/rtdebug.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/rtdef.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/rtlibc.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_stat.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_errno.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_fcntl.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_ioctl.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_dirent.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_signal.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread/cconfig.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_fdset.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_limits.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_stdio.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/rtservice.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/rtm.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\components\finsh/finsh_api.h

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rtconfig_preinc.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\components\drivers\include/drivers/spi.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/rtthread.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread/rtconfig.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/rtdebug.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/rtdef.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/rtlibc.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_stat.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_errno.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_fcntl.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_ioctl.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_dirent.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_signal.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread/cconfig.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_fdset.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_limits.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_stdio.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/rtservice.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/rtm.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\components\finsh/finsh_api.h:
