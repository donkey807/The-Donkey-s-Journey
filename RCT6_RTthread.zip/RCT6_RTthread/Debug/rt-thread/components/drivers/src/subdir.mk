################################################################################
# 自动生成的文件。不要编辑！
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../rt-thread/components/drivers/src/completion.c \
../rt-thread/components/drivers/src/dataqueue.c \
../rt-thread/components/drivers/src/pipe.c \
../rt-thread/components/drivers/src/ringblk_buf.c \
../rt-thread/components/drivers/src/ringbuffer.c \
../rt-thread/components/drivers/src/waitqueue.c \
../rt-thread/components/drivers/src/workqueue.c 

OBJS += \
./rt-thread/components/drivers/src/completion.o \
./rt-thread/components/drivers/src/dataqueue.o \
./rt-thread/components/drivers/src/pipe.o \
./rt-thread/components/drivers/src/ringblk_buf.o \
./rt-thread/components/drivers/src/ringbuffer.o \
./rt-thread/components/drivers/src/waitqueue.o \
./rt-thread/components/drivers/src/workqueue.o 

C_DEPS += \
./rt-thread/components/drivers/src/completion.d \
./rt-thread/components/drivers/src/dataqueue.d \
./rt-thread/components/drivers/src/pipe.d \
./rt-thread/components/drivers/src/ringblk_buf.d \
./rt-thread/components/drivers/src/ringbuffer.d \
./rt-thread/components/drivers/src/waitqueue.d \
./rt-thread/components/drivers/src/workqueue.d 


# Each subdirectory must supply rules for building sources it contributes
rt-thread/components/drivers/src/%.o: ../rt-thread/components/drivers/src/%.c
	arm-none-eabi-gcc -mcpu=cortex-m3 -mthumb -O0 -ffunction-sections -fdata-sections -Wall  -g -gdwarf-2 -DSOC_FAMILY_STM32 -DSOC_SERIES_STM32F1 -DUSE_HAL_DRIVER -DSTM32F103xE -I"G:\RT-ThreadStudio\workspace\RCT6_RTthread\drivers" -I"G:\RT-ThreadStudio\workspace\RCT6_RTthread\drivers\include" -I"G:\RT-ThreadStudio\workspace\RCT6_RTthread\drivers\include\config" -I"G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\CMSIS\Device\ST\STM32F1xx\Include" -I"G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\CMSIS\Include" -I"G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\CMSIS\RTOS\Template" -I"G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc" -I"G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc\Legacy" -I"G:\RT-ThreadStudio\workspace\RCT6_RTthread" -I"G:\RT-ThreadStudio\workspace\RCT6_RTthread\applications" -I"G:\RT-ThreadStudio\workspace\RCT6_RTthread" -I"G:\RT-ThreadStudio\workspace\RCT6_RTthread\cubemx\Inc" -I"G:\RT-ThreadStudio\workspace\RCT6_RTthread\cubemx" -I"G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\components\drivers\include" -I"G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\components\drivers\spi" -I"G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\components\finsh" -I"G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\components\libc\compilers\common" -I"G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include" -I"G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\libcpu\arm\common" -I"G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\libcpu\arm\cortex-m3" -include"G:\RT-ThreadStudio\workspace\RCT6_RTthread\rtconfig_preinc.h" -std=gnu11 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

