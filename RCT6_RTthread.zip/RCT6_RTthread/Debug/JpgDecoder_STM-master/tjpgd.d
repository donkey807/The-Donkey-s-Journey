JpgDecoder_STM-master/tjpgd.o: ../JpgDecoder_STM-master/tjpgd.c \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rtconfig_preinc.h \
 ../JpgDecoder_STM-master/tjpgd.h

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rtconfig_preinc.h:

../JpgDecoder_STM-master/tjpgd.h:
