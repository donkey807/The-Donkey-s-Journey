drivers/drv_common.o: ../drivers/drv_common.c \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rtconfig_preinc.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\drivers\include/drv_common.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/rtthread.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread/rtconfig.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/rtdebug.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/rtdef.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/rtlibc.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_stat.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_errno.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_fcntl.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_ioctl.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_dirent.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_signal.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread/cconfig.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_fdset.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_limits.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_stdio.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/rtservice.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/rtm.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\components\finsh/finsh_api.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/rthw.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\drivers/board.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\CMSIS\Device\ST\STM32F1xx\Include/stm32f1xx.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\CMSIS\Device\ST\STM32F1xx\Include/stm32f103xe.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\CMSIS\Include/core_cm3.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\CMSIS\Include/cmsis_version.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\CMSIS\Include/cmsis_compiler.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\CMSIS\Include/cmsis_gcc.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\CMSIS\Device\ST\STM32F1xx\Include/system_stm32f1xx.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\cubemx\Inc/stm32f1xx_hal_conf.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_rcc.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_def.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_rcc_ex.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_gpio.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_gpio_ex.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_exti.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_dma.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_dma_ex.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_cortex.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_adc.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_adc_ex.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_flash.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_flash_ex.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_pwr.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_rtc.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_rtc_ex.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_spi.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_uart.h \
 ../drivers/board.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\components\finsh/finsh.h \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\components\finsh/finsh_api.h

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rtconfig_preinc.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\drivers\include/drv_common.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/rtthread.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread/rtconfig.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/rtdebug.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/rtdef.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/rtlibc.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_stat.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_errno.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_fcntl.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_ioctl.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_dirent.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_signal.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread/cconfig.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_fdset.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_limits.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/libc/libc_stdio.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/rtservice.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/rtm.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\components\finsh/finsh_api.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\include/rthw.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\drivers/board.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\CMSIS\Device\ST\STM32F1xx\Include/stm32f1xx.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\CMSIS\Device\ST\STM32F1xx\Include/stm32f103xe.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\CMSIS\Include/core_cm3.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\CMSIS\Include/cmsis_version.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\CMSIS\Include/cmsis_compiler.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\CMSIS\Include/cmsis_gcc.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\CMSIS\Device\ST\STM32F1xx\Include/system_stm32f1xx.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\cubemx\Inc/stm32f1xx_hal_conf.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_rcc.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_def.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_rcc_ex.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_gpio.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_gpio_ex.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_exti.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_dma.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_dma_ex.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_cortex.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_adc.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_adc_ex.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_flash.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_flash_ex.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_pwr.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_rtc.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_rtc_ex.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_spi.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\libraries\STM32F1xx_HAL_Driver\Inc/stm32f1xx_hal_uart.h:

../drivers/board.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\components\finsh/finsh.h:

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rt-thread\components\finsh/finsh_api.h:
