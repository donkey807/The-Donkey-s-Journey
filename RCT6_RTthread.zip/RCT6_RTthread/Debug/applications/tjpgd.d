applications/tjpgd.o: ../applications/tjpgd.c \
 G:\RT-ThreadStudio\workspace\RCT6_RTthread\rtconfig_preinc.h \
 ../applications/tjpgd.h

G:\RT-ThreadStudio\workspace\RCT6_RTthread\rtconfig_preinc.h:

../applications/tjpgd.h:
