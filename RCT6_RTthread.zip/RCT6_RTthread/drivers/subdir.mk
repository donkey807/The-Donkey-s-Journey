################################################################################
# 自动生成的文件。不要编辑！
################################################################################

# Drivers
OBJ_SAVE := $(OBJ)
OBJ += $(wildcard drivers/*.o)
OBJ := $(filter-out drivers/drv_rtc.o,$(OBJ))
OBJ += drivers/drv_rtc.o

C_SRCS += \
drivers/drv_rtc.c \

OBJS := $(addprefix $(OUT)/,$(notdir $(OBJ)))
GEN_OPTS := $(addprefix $(OUT)/,$(notdir $(OBJ:.c=.opts)))
GEN_C_SRCS += $(addprefix $(OUT)/,$(notdir $(C_SRCS)))

C_DEPS += $(addprefix $(OUT)/,$(notdir $(C_SRCS:.c=.d)))

$(OUT)/%.o: drivers/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: MCU GCC Compiler'
	$(MAKE) $(GEN_OPTS) @$(OUT)/$*.opts
	@echo 'Finished building: $<'
	@echo ' '

$(OUT)/%.opts: drivers/%.c
	@echo 'Creating directory for: $<'
	@$(MKSPECS)/
	@$(file >$@)$(call generate_opts,$<)

-include $(C_DEPS)
